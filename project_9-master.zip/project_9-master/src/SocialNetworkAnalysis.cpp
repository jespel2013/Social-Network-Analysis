//----------------------------------------------------------------------//
// Author:
// Net ID:
// Date:
//
//----------------------------------------------------------------------//

#include "SocialNetworkAnalysis.h"
#include <fstream>
#include <string>
#include <iostream>
#include <queue>
#include <vector>
#include <algorithm>
#include <unordered_map>

using namespace std;
//USER
User::User() {
	_depth = 4;
	return;
}

bool User::operator<(const User& rhs) const {
	if (_followers.size() > (unsigned)rhs.GetFollowers().size()) {
		return true;
	}
	if (_followers.size() == (unsigned)rhs.GetFollowers().size() && _name < rhs.GetName()) {
		return true;
	}
	return false;
}

//  SOCIAL NETWORK ANALYSIS

SocialNetworkAnalysis::SocialNetworkAnalysis(string inputFilePath, string outputFilePath){
    _inputFilePath = inputFilePath;
    _outputFilePath = outputFilePath;
}

void SocialNetworkAnalysis::Run(){
	

	ReadNetwork();
	SetDepths();
	WriteOutput();
	return;

}


void SocialNetworkAnalysis::ReadNetwork() {
	ifstream inFile;
	std::string word1;
	std::string word2;
	User tempUser1;
	User tempUser2;
	unsigned int i;
	unsigned int word1found = 0;
	unsigned int word2found = 0;

	inFile.open(_inputFilePath);


	if (!inFile.is_open()) {
		cout << "Input file path invalid" << endl;
		return;
	}

	//std::vector<User> tempUsers;

	inFile >> word1;


	_rootUser.SetName(word1);

	while (inFile >> word1 >> word2) {
		word1found = 200000;
		word2found = 200000;
		//search vector for user
		for (i = 0; i < _users.size(); i++) {
			if (_users[i].GetName().compare(word1) == 0) {
				word1found = i;
			}
			else if (_users[i].GetName().compare(word2) == 0) {
				word2found = i;
			}

		}

		//add if not found
		if (word1found == 200000) {
			word1found = _users.size();
			tempUser1.SetName(word1);
			_users.push_back(tempUser1);
			
		}
		if (word2found == 200000) {
			word2found = _users.size();
			tempUser1.SetName(word2);
			_users.push_back(tempUser1);
		}

		_users[word1found].AddFollower(&_users[word2found]);
		_users[word2found].AddFollowing(&_users[word1found]);

	}

	inFile.close();
	return;

}

void SocialNetworkAnalysis::SetDepths() {
	//set root User
	// this is nothing

	



	return;
}

void SocialNetworkAnalysis::WriteOutput() {
	ofstream outFile;
	outFile.open(_outputFilePath);
	
	if (!outFile.is_open()) {
		cout << "Output File Path invalid" << endl;
		return;
	}
	



	
	for (unsigned int i = 0; i < _users.size(); i++) {
		outFile << _users[i].GetName() << "  " << _users[i].GetDepth() <<endl;
	}

	outFile.close();
	return;

}

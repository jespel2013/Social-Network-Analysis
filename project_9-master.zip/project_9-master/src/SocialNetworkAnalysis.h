//----------------------------------------------------------------------//
// Author:
// Net ID:
// Date:
//
//----------------------------------------------------------------------//

#ifndef SOCIALNETWORKANALYSIS_H
#define SOCIALNETWORKANALYSIS_H

#include <string>
#include <vector>

class User {
private:
	std::string _name;
	unsigned int _depth;
	std::vector<User*> _followers;
	std::vector<User*> _following;

public:
	User();
	std::string GetName() const { return _name; };
	void SetName(std::string userName) { _name = userName; return; };
	void AddFollower(User* follower) { _followers.push_back(follower); return; };
	void AddFollowing(User* following) { _following.push_back(following); return; };
	std::vector<User*> GetFollowers() const { return _followers; };
	std::vector<User*> GetFollowing() { return _following; };
	bool operator<(const User& rhs) const;
	unsigned int GetDepth() { return _depth; };
	void SetDepth(unsigned int depth) { _depth = depth; return; };
	void SetFollowing(std::vector<User*> following) { _following = following; return; };
	
};




class SocialNetworkAnalysis{
private:
    std::string _inputFilePath;
    std::string _outputFilePath;

	User _rootUser;
	std::vector<User> _users;
public:
    SocialNetworkAnalysis(std::string inputFilePath, std::string ouputFilePath);
    void Run();
	void ReadNetwork();
	

	User GetRootUser() { return _rootUser; };
	void SetRootUser(User root) { _rootUser = root; return; };
	std::vector<User> GetUsers() { return _users; };
	void SetUsers(std::vector<User> users) { _users = users; return; };
	void WriteOutput();
	void SetDepths();
};
#endif /* SocialNetworkAnalysis_hpp */
